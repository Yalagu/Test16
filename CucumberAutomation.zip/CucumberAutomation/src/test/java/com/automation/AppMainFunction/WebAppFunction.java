package com.automation.AppMainFunction;

import com.automation.WebCommonFunction.DriverUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.io.File;
import java.util.List;

public class WebAppFunction extends DriverUtils {

    @FindBy(xpath="//a[normalize-space()='LAUNCH']")
    public WebElement launchBtn;

    @FindBy(xpath="//div[@class='screener-tab']/following-sibling::span")
    public WebElement settingsBtn;


    @FindBy(xpath="//label[normalize-space()='Benchmark:']")
    public WebElement benchMarkText;
    @FindBy(xpath="//div[@class='animate__animated animate__fadeInDown']")
    public WebElement settingDropDownDrawer;

    @FindBy(xpath="//input[contains(@id,'products-multiselect')]")
    public WebElement benchMarkDropDown;

    @FindBy(xpath="//div[@class='loading'][@hidden]")
    public WebElement loadingIconDisable;


    @FindBy(xpath="//div[@class='k-list-content k-list-scroller']//ul")
    public WebElement orgDropDownDrawer;

    @FindBy(xpath="//label[@for='portfolio-upload']/span")
    public WebElement portofiloUploadIcon;

    @FindBy(xpath="//a[@title='Download Sample Template']")
    public WebElement downloadSampleTemplate;

    @FindBy(xpath="//input[@id='portfolio-name']")
    public WebElement inputPortfolioName;

    @FindBy(xpath="//button[@type='submit'][not (@aria-disabled='true')]/span[normalize-space()='Ok']")
    public WebElement uploadSumbitBtn;

    @FindBy(xpath = "//input[@type='file']")
    public WebElement fileUploadDocument;

    @FindBy(xpath="//div[@class='k-popup k-list-container']//ul")
    public WebElement currencyDropDownDrawer;

    @FindBy(xpath="//label[normalize-space()='Origination:']/following-sibling::span//span[@class='k-input-value-text' and normalize-space()='Select']")
    public WebElement originationDropDown;

    @FindBy(xpath="//label[normalize-space()='Portfolio Selection:']/following-sibling::span//span[@class='k-input-value-text' and normalize-space()='Select']")
    public WebElement portfolioDropDown;

    @FindBy(xpath="//label[normalize-space()='Currency:']/following-sibling::span//span[@class='k-input-value-text' ]")
    public WebElement selectCurrency;

    @FindBy(xpath="//label[normalize-space()='Portfolio Selection:']/following-sibling::span//span[@class='k-input-value-text' and normalize-space()='Select']")
    public WebElement whilShireToggle;

    @FindBy(xpath="//span[normalize-space()='Relative' and contains(@class,'k-switch-track k-rounded-full')]")
    public WebElement relativeToggle;


    @FindBy(xpath="//span[@class='k-switch k-mr-2 telerik-blazor k-switch-on k-rounded-full k-switch-md']/following-sibling::span/*[@class='k-input-inner']")
    public WebElement relativeToggleDropDown;

    @FindBy(xpath="(//table[@class='search-table'])[1]//tr[@class='rowItem']")
    public List<WebElement> searchListIcon;

    @FindBy(xpath="(//*[local-name()='g' and @class='highcharts-axis-labels highcharts-xaxis-labels'])[1]/*")
    public List<WebElement> exploureXaxisIcon;

    @FindBy(xpath="//h5[@class='k-card-title']")
    public List<WebElement> exposureHistoryIcon;


    WebElement webElement=null;


    private static final Logger logger = LoggerFactory.getLogger(WebAppFunction.class);
    public  void  setUrl(){
        String appUrl=getValueFromProperitesFile("MainAppUrl");
        driver.get(String.valueOf(appUrl));
        logger.info("Launched url:"+appUrl);
    }
    public void clickOnSettingBtn(){
        waitForElementToBePresent(50,settingsBtn);
        click(settingsBtn);
        waitForElementToBePresent(100,benchMarkText);
        isElementDisplayed(settingDropDownDrawer);
        System.out.println("no1");
    }

    public void selectOptionFromBenchMark(String selectValue) throws Exception {
        waitForElementToBePresent(50,benchMarkDropDown);
        waitStatement("3");
        click(benchMarkDropDown);
//        setValueStaleElement(benchMarkDropDown,selectValue);
        waitForElementToBePresent(50,orgDropDownDrawer);
        waitForElementToBePresent(50,"xpath","//li[@role='option']//span[normalize-space()='"+selectValue+"']");
        webElement=driver.findElement(By.xpath("//li[@role='option']//span[normalize-space()='"+selectValue+"']"));
        click(webElement);
    }
    public void waitStatement(String waitTime){
       try{
           Thread.sleep(1000*(Integer.valueOf(waitTime)));
       }catch (Exception e){

       }
    }
    public void selectOptionFromOrganization(String selectValue){
        waitForElementToBePresent(50,originationDropDown);
        click(originationDropDown);
        waitForElementToBePresent(50,orgDropDownDrawer);
        waitForElementToBePresent(50,"xpath","//li[@role='option']//span[normalize-space()='"+selectValue+"']");
        WebElement webElement=driver.findElement(By.xpath("//li[@role='option']//span[normalize-space()='"+selectValue+"']"));
        click(webElement);
    }

    public void selectPortofilioFromOrganization(String selectValue){
        waitForElementToBePresent(50,portfolioDropDown);
        click(portfolioDropDown);
        waitForElementToBePresent(50,orgDropDownDrawer);
        waitForElementToBePresent(50,"xpath","//li[@role='option']//span[normalize-space()='"+selectValue+"']");
        webElement=driver.findElement(By.xpath("//li[@role='option']//span[normalize-space()='"+selectValue+"']"));
        click(webElement);
    }
    public void uploadPortofilioFromOrganization(String uploadTemplateName,String templateName) throws Exception {
        waitForElementToBePresent(50,portofiloUploadIcon);
        deleteDownloadedFile("PortfolioTemplate","csv");
        click(portofiloUploadIcon);
        waitForElementToBePresent(50,downloadSampleTemplate);
        click(downloadSampleTemplate);
        waitTillTheFileDownloaded(uploadTemplateName);
        File uploadFile = new File(resourcesDirectory.getAbsolutePath()+"\\"+uploadTemplateName);
        uploadFile = new File(uploadFile.getAbsolutePath());
        logger.info(String.valueOf(uploadFile));
        fileUploadDocument.sendKeys(uploadFile.getAbsolutePath());
        click(inputPortfolioName);
        inputPortfolioName.clear();
        setValueStaleElement(inputPortfolioName,templateName.replace("_randomId",String.valueOf(randomNumber)));
        click(uploadSumbitBtn);
        waitForElementToBePresent(500,loadingIconDisable);
    }

    public void selectCurrencyType(String selectValue){
        waitForElementToBePresent(50,selectCurrency);
        click(selectCurrency);
        waitForElementToBePresent(50,currencyDropDownDrawer);
        waitForElementToBePresent(50,"xpath","//li[@role='option']//span[normalize-space()='"+selectValue+"']");
        webElement=driver.findElement(By.xpath("//li[@role='option']//span[normalize-space()='"+selectValue+"']"));
        click(webElement);
    }

    public void clickBtn(String btnText){
        waitForElementToBePresent(50,"xpath","//button/span[normalize-space()='"+btnText+"']");
        webElement=driver.findElement(By.xpath("//button/span[normalize-space()='"+btnText+"']"));
        click(webElement);
    }

    public void clickBtnTilt(String btnText){
        waitForElementToBePresent(50,"xpath","//span[normalize-space()='"+btnText+"']/parent::button[@type='submit']");
        webElement=driver.findElement(By.xpath("//span[normalize-space()='"+btnText+"']/parent::button[@type='submit']"));
        click(webElement);
    }

    public void loadingIconDisablePosition(){
        waitForElementToBePresent(500,loadingIconDisable);
        logger.info("loading completed..");

    }
    public void waitingForTextTab(String btnText){
        waitForElementToBePresent(200,"xpath","//ul//div[text()='"+btnText+"']");

    }
    public void clickOnRightSideTab(String btnText){
        waitForElementToBePresent(200,"xpath","//ul//div[text()='"+btnText+"']");
        click(driver.findElement(By.xpath("//ul//div[text()='"+btnText+"']")));
    }

    public void selectSearchOptionInExposureTab(String name){
        for(int i=0;i<exploureXaxisIcon.size();i++){
            if(getText(exploureXaxisIcon.get(i)).equalsIgnoreCase(name)){
                click(searchListIcon.get(i));
            }
        }
    }

    public void validateExposureHistoryTap(String names){
        List<String> displayName=getAllText(exposureHistoryIcon);
        for(String name:names.split(",")){
            Assert.assertEquals(true,displayName.contains(name),"expected name not found:"+name);
        }
    }

    public void waitingTitleHeader(String titleHeaderName){
        waitForElementToBePresent(200,"xpath"," //div[@class='title-header' and text()='"+titleHeaderName+"']|//label[text()='"+titleHeaderName+"']");

    }

    public void navigateToSideTap(String btnText){
        waitForElementToBePresent(200,"xpath","//ul//div[text()='"+btnText+"']");
        webElement=driver.findElement(By.xpath("//ul//div[text()='"+btnText+"']"));
        click(webElement);
    }


    public void navigateScreenerTap(String btnText){
        waitForElementToBePresent(200,"xpath","//div[@class='screener-tab']//h5[text()='"+btnText+"']");
        webElement=driver.findElement(By.xpath("//div[@class='screener-tab']//h5[text()='"+btnText+"']"));
        click(webElement);
    }

    public void clickOnWilShireToggle(){
        waitForElementToBePresent(100,whilShireToggle);
        click(whilShireToggle);
    }

    public void clickOnRelativeToggle(){
        waitForElementToBePresent(100,relativeToggle);
        click(relativeToggle);
        waitForElementToBePresent(100,relativeToggleDropDown);
    }



    public void updateInMainHeaderInput(String inputBoxName,String value){
        waitForElementToBePresent(50,"xpath","//label[text()='"+inputBoxName+"']/following-sibling::div//input");
        WebElement webElement=driver.findElement(By.xpath("//label[text()='"+inputBoxName+"']/following-sibling::div//input"));
        click(webElement);
        waitForElementToBePresent(100,orgDropDownDrawer);
        waitForElementToBePresent(50,"xpath","//li[@role='option']//span[normalize-space()='"+value+"']");
        webElement=driver.findElement(By.xpath("//li[@role='option']//span[normalize-space()='"+value+"']"));
        click(webElement);
    }

    public void updateTiltBoxInput(String inputBoxName,String value){
        String xpath="//label[text()='"+inputBoxName+"']/../following-sibling::div[contains(@class,'tilttext')]//input";
        waitForElementToBePresent(50,"xpath",xpath);
        WebElement webElement=driver.findElement(By.xpath(xpath));
        webElement.clear();
        typeCharacter(webElement,value);
    }

    public void clickOnMainHeaderInput(String inputBoxName){
        waitForElementToBePresent(50,"xpath","//label[text()='"+inputBoxName+"']/following-sibling::div//input");
        WebElement webElement=driver.findElement(By.xpath("//label[text()='"+inputBoxName+"']/following-sibling::div//input"));
        click(webElement);
        waitForElementToBePresent(100,orgDropDownDrawer);
    }

    public void verifyGraphXaxisYAxis(String xaxisName,String yAxisName){
        Assert.assertEquals(isElementDisplayed(driver.findElement(By.xpath("//*[normalize-space()='"+xaxisName+"' and @text-anchor='start']"))),true,"Xaxis name not matching");
        Assert.assertEquals(isElementDisplayed(driver.findElement(By.xpath("//*[@class='highcharts-axis-title' and text()='"+yAxisName+"']"))),true,"Yaxis name not matching");
    }



}
