package com.automation.MobileWebMainFunction;

import com.automation.WebCommonFunction.DriverUtils;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.automation.MobileWebMainFunction.BaseClass.driver;

public class MobileWebFunction extends DriverUtils {

    WebElement element=null;

    public void setAcceptAllCookies() throws InterruptedException {
            if(isElementDisplayedID("accept-all-cookies-button")){
                click(driver.findElement(By.id("accept-all-cookies-button")));
            }
    }

    public void clickOnSignOutBtn() throws InterruptedException {
        scrollIntoView(driver.findElement(By.id("signup-btn")));
        click(driver.findElement(By.id("signup-btn")));
    }

    public void clickOnSignUpConfirmBtn() throws InterruptedException {
        element=driver.findElement(By.xpath("(//button[normalize-space()='Sign up'])[2]"));
        scrollIntoView(element);
        Thread.sleep(3000);
        click(element);
        if(isElementDisplayed(element)){
            Thread.sleep(2000);
            click(element);
        }

    }

    public void waitTillUserNameUntilShow(String name) throws InterruptedException {
        element=driver.findElement(By.xpath("//my-pi-wrapper//div[normalize-space()='"+name+"']"));
        Thread.sleep(3000);
        if(isElementDisplayed(element)){
            driver.findElement(By.xpath("//close-button//div/*"));
        }
    }

    public void verifySucesssMsg() throws InterruptedException {
       isElementDisplayed(driver.findElement(By.xpath("//*[contains(normalize-space(),'Thanks')]")));
    }

    public void verifyPaymentDeatilsHeaderMsg() throws InterruptedException {
        isElementDisplayed(driver.findElement(By.xpath("//*[contains(normalize-space(),'Card details')]")));
    }

    public void enterFirstName(String value) throws InterruptedException {
        element=driver.findElement(By.xpath("//input[@aria-label='First Name:']"));
        click(element);
        element.sendKeys(value.replace("random",randomString));
    }
    public void enterLastName(String lastName) throws InterruptedException {
        element=driver.findElement(By.xpath("//input[@aria-label='Last Name:']"));
        click(element);
        element.sendKeys(lastName.replace("random",randomString));
    }
    public void enterEmail(String email) throws InterruptedException {
        element=driver.findElement(By.xpath("//input[@aria-label='Email: ']"));
        click(element);
        element.sendKeys(email.replace("random",randomString));
    }

    public void clickOnHambergurerMenu() throws  Exception{
        element=driver.findElement(By.xpath("//div[@id='pi-menu-button']/*/*"));
        click(element);
    }

    public void clickOnLoginBtn() throws  Exception{
        element=driver.findElement(By.xpath("//div[@id='mobile-login-tab']"));
        click(element);
    }

    public void clickOnLoginSubmitBtn() throws  Exception{
        element=driver.findElement(By.xpath("//button[@id='submit-button']"));
        scrollIntoView(element);
        Thread.sleep(3000);
        click(element);
        if(isElementDisplayed(element)){
            Thread.sleep(2000);
            click(element);
        }
    }

    public void enterLoginEmailInputValue(String emailName) throws  Exception{
        element=driver.findElement(By.xpath("//input[@id='email-input']"));
        click(element);
        element.sendKeys(emailName.replace("random",randomString));
    }

    public void enterLoginPwdInputValue(String emailName) throws  Exception{
        element=driver.findElement(By.xpath("//input[@id='password-input']"));
        click(element);
        element.sendKeys(emailName.replace("random",randomString));
    }


    public void enterLocationName(String locationName) throws  Exception{
        element=driver.findElement(By.xpath("//search-console-form-location-input//input"));
        click(element);
        element.sendKeys(locationName.replace("random",randomString));
        element=driver.findElement(By.xpath("//search-suggestion//li[normalize-space()='"+locationName+"']"));
    }

    public void enterDateDefaultDate() throws  Exception{
        element=driver.findElement(By.xpath("//search-console__form-date-picker//input"));
        click(element);
        element=driver.findElement(By.xpath("//calendar-container//button[normalize-space()='Done']"));
        click(element);
    }

    public void enterHotelSearchBtn() throws  Exception{
        element=driver.findElement(By.xpath(" //button[@id='search-console__form-button']"));
        click(element);
    }

    public void selectHotelNameBasedOnIndex(String index) throws  Exception{
        isElementDisplayedXpath("(//div[@data-testid='SRP-hotel-button'])["+index+"]");
        element=driver.findElement(By.xpath("(//div[@data-testid='SRP-hotel-button'])["+index+"]"));
        click(element);
    }

    public void clickOnBookNowBtn() throws  Exception{
        element=driver.findElement(By.xpath("//button[@data-testid='book-now']"));
        scrollIntoView(element);
        Thread.sleep(3000);
        click(element);
        if(isElementDisplayed(element)){
            Thread.sleep(2000);
            click(element);
        }
    }

    public void clickAddPlusBtn(String count) throws  Exception{
        isElementDisplayedXpath("(//button[@class='counter__control-plus']/*)[1]");
        element=driver.findElement(By.xpath("(//button[@class='counter__control-plus']/*)[1]"));
        scrollIntoView(element);
        Thread.sleep(3000);
        click(element);
        WebElement welement=driver.findElement(By.xpath("(//button[@class='counter__control-plus']/*)[1]"));
        if(!(welement.getText().equalsIgnoreCase(count))){
            Thread.sleep(2000);
            click(element);
        }
    }

    public void clickOnContinueBtn() throws  Exception{
        element=driver.findElement(By.xpath("(//button[@class='wb-btn submit-details__button-primary'])[2]"));
        scrollIntoView(element);
        Thread.sleep(3000);
        click(element);
        if(isElementDisplayed(element)){
            Thread.sleep(2000);
            click(element);
        }
    }

    public void clickContinueToNext() throws  Exception{
        isElementDisplayedXpath("//button[@class='wb-btn wb-btn--primary button']");
        element=driver.findElement(By.xpath("//button[@class='wb-btn wb-btn--primary button']"));
        scrollIntoView(element);
        Thread.sleep(3000);
        click(element);
        if(isElementDisplayed(element)){
            Thread.sleep(2000);
            click(element);
        }
    }

    public void reasonForStay(String type) throws  Exception{
        element=driver.findElement(By.xpath("(//label//span[normalize-space()='"+type+"'])[2]"));
        click(element);
    }

    public void clickOnTermsAndCondition() throws  Exception{
        element=driver.findElement(By.xpath("//label[@for='singleCheckboxWhite']"));
        click(element);
    }

}
